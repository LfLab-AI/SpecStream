# SpecStream first-grant-before-first-forward 修复包

## 当前根因

日志已经证明不是 OOM：Drafter 完成 CUDA Graph capture、仍有约 45.96 GB 可用显存，
随后第一次进入受 `smctrl` 控制的 forward 时没有 active TPC mask，触发安全检查：

`SpecStream refused an ungranted Draft forward: no TPC mask is active`

并且移除 `--spectre-draft-priority` 会被另一条安全检查拒绝，所以 priority 模式必须保留。

## 本修复的关键原则

1. 普通/本地/warmup forward 与受 I2 grant 控制的 remote Draft forward 分开。
2. 只有 scheduler 显式标记的 controlled Draft forward 才要求 active mask。
3. fixed-TPC calibration 在首个 controlled forward 前建立持久 spatial mask。
4. online 模式无 grant 时 Drafter priority phase 直接 return/idle，绝不 `run_batch()`。
5. online 模式每个 grant 最多执行一个 Draft token。
6. `tp_worker.py` 原来的 fail-closed 检查不删除，只缩小到正确的 controlled-forward 边界。

## 文件

- `draft_grant_runtime.py`
  - 完整 grant gate 实现
  - calibration bootstrap grant
  - online one-token grant
  - epoch/deadline/request-id 检查

- `apply_first_grant_fix.py`
  - 自动备份并修改：
    - `spectre_draft_scheduler_mixin.py`
    - `tp_worker.py`
  - 把 `draft_grant_runtime.py` 安装到 `specstream/`
  - 最后自动做 Python syntax compile

- `test_first_grant_gate.py`
  - grant gate 单元测试

## 安装

解压到任意目录后：

```bash
cd ~/lifei/SpecStream
conda activate spectre
export PYTHONPATH=$PWD/python:${PYTHONPATH:-}

cp /path/to/specstream_first_grant_fix/* scripts/specstream/

python scripts/specstream/apply_first_grant_fix.py
python -m pip install -e ./python --no-deps

cp scripts/specstream/test_first_grant_gate.py   python/sglang/test/spectre_specstream/test_first_grant_gate.py

PYTHONPATH=python pytest -q   python/sglang/test/spectre_specstream/test_first_grant_gate.py

PYTHONPATH=python pytest -q   python/sglang/test/spectre_specstream
```

补丁会创建备份：

```text
spectre_draft_scheduler_mixin.py.first_grant.bak
tp_worker.py.first_grant.bak
```

## 先只跑 Gate 3

固定：

```text
q=4
TPC=4
INPUT_LEN=16384
OUTPUT_LEN=32
NUM_PROMPTS=4
MAX_CONCURRENCY=1
```

Drafter 日志应看到：

```text
SpecStream calibration bootstrap grant active before first Draft forward
```

并且不能再有：

```text
ungranted Draft forward
no TPC mask is active
Draft exited before readiness
```

## 在线 D4/D5 的边界

这个修复会尝试兼容当前分支已有的 coexec runtime hook。获取 grant 时依次尝试：

```text
try_acquire_one_token
try_acquire_draft_grant
acquire_draft_grant
get_active_draft_grant
current_draft_grant
```

完成一步后依次尝试：

```text
complete_draft_step
ack_draft_grant
complete_one_token
mark_draft_step_complete
```

如果当前 `coexec_runtime.py` 的真实方法名不属于这些名字，D4/D5 会安全地停留在
NO_GRANT，而不会执行未授权 forward。由于当前完整 `coexec_runtime.py` 源文件没有出现在已上传材料中，
本补丁不会盲目覆盖它；fixed-TPC Gate/calibration 可以先验证通过，再做在线 API 的一对一对接。
