#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-$PWD}"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$REPO"

mkdir -p scripts/specstream
cp "$SELF_DIR/draft_grant_runtime.py" scripts/specstream/draft_grant_runtime.py
cp "$SELF_DIR/apply_first_grant_fix.py" scripts/specstream/apply_first_grant_fix.py
cp "$SELF_DIR/test_first_grant_gate.py" scripts/specstream/test_first_grant_gate.py

python scripts/specstream/apply_first_grant_fix.py
python -m pip install -e ./python --no-deps

cp scripts/specstream/test_first_grant_gate.py   python/sglang/test/spectre_specstream/test_first_grant_gate.py

PYTHONPATH=python pytest -q   python/sglang/test/spectre_specstream/test_first_grant_gate.py
