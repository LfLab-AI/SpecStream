#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import datetime
import py_compile
import shutil

REPO = Path.cwd()

FILES = {
    "server_args": REPO / "python/sglang/srt/server_args.py",
    "config": REPO / "python/sglang/srt/speculative/spectre/specstream/config.py",
    "verifier": REPO / "python/sglang/srt/speculative/spectre/specstream/verifier.py",
    "target_sched": REPO / "python/sglang/srt/speculative/spectre/verifier/spectre_target_scheduler_mixin.py",
}

stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
BACKUP = REPO / ".specstream_backups" / f"draft_only_true_parallel_{stamp}"


def die(msg: str) -> None:
    raise SystemExit("ERROR: " + msg)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        die(f"{label}: expected exactly one anchor, found {count}")
    return text.replace(old, new, 1)


for name, path in FILES.items():
    if not path.exists():
        die(f"missing {name}: {path}")

src = {name: path.read_text(encoding="utf-8") for name, path in FILES.items()}

if "specstream_smctrl_complementary_partition" not in src["server_args"]:
    die("complementary-TPC support not found; apply that patch first")
if "runtime.overlap_grants(" not in src["target_sched"]:
    die("continuous-overlap support not found; apply true-parallel patch first")
if "def overlap_grants(" not in src["verifier"]:
    die("SpecStreamTargetRuntime.overlap_grants() missing")

# 1) server_args.py
s = src["server_args"]
if "specstream_smctrl_draft_only_parallel" not in s:
    s = replace_once(
        s,
        "    specstream_smctrl_complementary_partition: bool = False\n"
        "    specstream_tp_straggler_control: bool = False\n",
        "    specstream_smctrl_complementary_partition: bool = False\n"
        "    specstream_smctrl_draft_only_parallel: bool = False\n"
        "    specstream_tp_straggler_control: bool = False\n",
        "server_args field",
    )

    next_arg = '''        parser.add_argument(
            "--specstream-tp-straggler-control",'''
    if next_arg not in s:
        die("server_args parser anchor not found")
    cli = '''        parser.add_argument(
            "--specstream-smctrl-draft-only-parallel",
            action="store_true",
            default=ServerArgs.specstream_smctrl_draft_only_parallel,
            help=(
                "Run Target and Drafter concurrently on one GPU while masking "
                "only the Drafter. Target keeps the full GPU/TPC set. Do not "
                "combine with --specstream-smctrl-complementary-partition."
            ),
        )
'''
    s = s.replace(next_arg, cli + next_arg, 1)
src["server_args"] = s

# 2) config.py
s = src["config"]
if "smctrl_draft_only_parallel" not in s:
    s = replace_once(
        s,
        "    smctrl_complementary_partition: bool = False\n"
        "    tp_straggler_control: bool = False\n",
        "    smctrl_complementary_partition: bool = False\n"
        "    smctrl_draft_only_parallel: bool = False\n"
        "    tp_straggler_control: bool = False\n",
        "config field",
    )

    validation_anchor = '''        if (
            self.smctrl_complementary_partition
            and self.smctrl_mask_scope != "global"
        ):
            raise ValueError(
                "complementary TPC partition requires "
                "--specstream-smctrl-mask-scope global"
            )
'''
    validation_repl = validation_anchor + '''        if self.smctrl_draft_only_parallel and not self.smctrl_enabled:
            raise ValueError(
                "draft-only parallel mode requires --specstream-smctrl-enabled"
            )
        if self.smctrl_draft_only_parallel and self.smctrl_complementary_partition:
            raise ValueError(
                "--specstream-smctrl-draft-only-parallel and "
                "--specstream-smctrl-complementary-partition are mutually exclusive"
            )
'''
    s = replace_once(s, validation_anchor, validation_repl, "config validation")

    s = replace_once(
        s,
        '''            smctrl_complementary_partition=bool(
                server_args.specstream_smctrl_complementary_partition
            ),
            tp_straggler_control=bool(server_args.specstream_tp_straggler_control),
''',
        '''            smctrl_complementary_partition=bool(
                server_args.specstream_smctrl_complementary_partition
            ),
            smctrl_draft_only_parallel=bool(
                server_args.specstream_smctrl_draft_only_parallel
            ),
            tp_straggler_control=bool(server_args.specstream_tp_straggler_control),
''',
        "config from_server_args",
    )
src["config"] = s

# 3) verifier.py
s = src["verifier"]

old_cond = "        if config.smctrl_enabled and config.smctrl_complementary_partition:\n"
new_cond = (
    "        if (\n"
    "            config.smctrl_enabled\n"
    "            and config.smctrl_complementary_partition\n"
    "            and not config.smctrl_draft_only_parallel\n"
    "        ):\n"
)
if old_cond in s:
    s = s.replace(old_cond, new_cond, 1)
elif "and not config.smctrl_draft_only_parallel" not in s:
    die("Target complementary SMController condition not found")

if "SpecStream draft-only true parallel" not in s:
    anchor = "        self.mps_environment = read_mps_environment()\n"
    block = '''        if config.smctrl_enabled and config.smctrl_draft_only_parallel:
            logger.info(
                "SpecStream draft-only true parallel: Target TPC mask is DISABLED; "
                "Target keeps all visible TPCs while Drafter alone is TPC-limited"
            )

'''
    if anchor not in s:
        die("verifier MPS anchor not found")
    s = s.replace(anchor, block + anchor, 1)

begin_pos = s.find("    def begin_target_partition(self, batch, meta=None) -> bool:\n")
if begin_pos < 0:
    die("begin_target_partition not found")
window = s[begin_pos:begin_pos + 1400]
if "self.config.smctrl_draft_only_parallel" not in window:
    old = '''        if self.target_smctrl is None:
            return False
'''
    new = '''        if self.config.smctrl_draft_only_parallel:
            # Mainline policy: Target remains unrestricted. Only Drafter is
            # TPC-limited, while continuous SLACK_FILL still overlaps Draft
            # tokens with the asynchronous Target forward.
            return False
        if self.target_smctrl is None:
            return False
'''
    sub = s[begin_pos:]
    if old not in sub:
        die("begin_target_partition early-return anchor not found")
    sub = sub.replace(old, new, 1)
    s = s[:begin_pos] + sub

src["verifier"] = s

# 4) target scheduler: keep continuous grant pump, skip Target pre-arm in
# draft-only mode.
s = src["target_sched"]

old_prearm = '''                    partition_prearmed = False
                    if grant_reqs and runtime is not None:
                        begin_partition = getattr(
                            runtime, "begin_target_partition", None
                        )
                        if begin_partition is not None:
                            partition_prearmed = bool(
                                begin_partition(batch, None)
                            )
'''
new_prearm = '''                    partition_prearmed = False
                    draft_only_parallel = bool(
                        getattr(
                            getattr(runtime, "config", None),
                            "smctrl_draft_only_parallel",
                            False,
                        )
                    )
                    if (
                        grant_reqs
                        and runtime is not None
                        and not draft_only_parallel
                    ):
                        begin_partition = getattr(
                            runtime, "begin_target_partition", None
                        )
                        if begin_partition is not None:
                            partition_prearmed = bool(
                                begin_partition(batch, None)
                            )
'''
if old_prearm in s:
    s = s.replace(old_prearm, new_prearm, 1)
elif "draft_only_parallel = bool(" not in s:
    die("Target pre-arm block not found")

s = s.replace(
    '''                    # Install Target=[k,N) before the first SLACK_FILL grant is
                    # visible to Drafter.  This closes the old launch-order race
                    # where Draft could observe [0,k) before Target had applied
                    # its complementary process-global mask.
''',
    '''                    # Complementary-ablation mode pre-arms Target=[k,N).
                    # Mainline draft-only mode intentionally skips Target masking:
                    # Target stays unrestricted while Drafter alone uses [0,k).
''',
    1,
)

src["target_sched"] = s

# Validate staged code before writing.
for key, path in FILES.items():
    compile(src[key], str(path), "exec")

BACKUP.mkdir(parents=True, exist_ok=True)
for path in FILES.values():
    dst = BACKUP / path.relative_to(REPO)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dst)

for key, path in FILES.items():
    path.write_text(src[key], encoding="utf-8")
    py_compile.compile(str(path), doraise=True)

print("=" * 78)
print("SpecStream draft-only true-parallel mode applied")
print("=" * 78)
print("backup:", BACKUP)
print("Target : unrestricted full visible GPU/TPC set")
print("Draft  : TPC-limited by one-token grants [0,k)")
print("Target forward running: ACK -> next SLACK_FILL immediately")
print("Target forward complete: remaining Draft -> DRAFT_CATCHUP")
print("New Target flag: --specstream-smctrl-draft-only-parallel")
print("Do NOT combine with --specstream-smctrl-complementary-partition")
print("py_compile: PASS")
