# SpecStream：仅限制 Drafter、Target 保持全资源的真正并行模式

主策略：

```text
Target: [0, N)   不做 TPC 限制
Draft : [0, k)   只限制 Drafter
```

同时保留 continuous SLACK_FILL：

```text
Target:
|==================== VERIFY ====================|

Draft:
   |D1| |D2| |D3| |D4|
```

只要 Target CUDA forward 还没完成，每个 Draft token ACK 后都会立刻发下一个
one-token `SLACK_FILL` grant；Target 完成后剩余 Draft token 自动进入
`DRAFT_CATCHUP`。

## 应用

```bash
cd ~/lifei/SpecStream
conda activate spectre

python /path/to/apply_draft_only_true_parallel.py
python -m pip install -e ./python --no-deps
```

语法检查：

```bash
python -m py_compile   python/sglang/srt/server_args.py   python/sglang/srt/speculative/spectre/specstream/config.py   python/sglang/srt/speculative/spectre/specstream/verifier.py   python/sglang/srt/speculative/spectre/verifier/spectre_target_scheduler_mixin.py
```

## Target 参数

```bash
--specstream-smctrl-enabled --specstream-smctrl-draft-only-parallel --specstream-smctrl-library "$SMCTRL_LIB" --specstream-smctrl-mask-scope global
```

不要再传：

```bash
--specstream-smctrl-complementary-partition
```

Target 保留 `--specstream-smctrl-enabled` 是为了启用 TargetGrantRuntime /
continuous grant 控制，不是为了给 Target 安装 TPC mask。

## Drafter 参数

```bash
--specstream-smctrl-enabled --specstream-smctrl-library "$SMCTRL_LIB" --specstream-smctrl-mask-scope global
```

固定 TPC 校准仍用：

```bash
--specstream-smctrl-calibration-tpcs 4
```

因此实际空间关系是：

```text
Target=[0,N)
Draft =[0,4)
```

## 推荐 Gate

Target：

```bash
export CAL_TARGET_COMMON="$I2_TARGET_COMMON   --specstream-profile-only   --specstream-smctrl-enabled   --specstream-smctrl-draft-only-parallel   --specstream-smctrl-library '$SMCTRL_LIB'   --specstream-smctrl-mask-scope global   --specstream-coexec-target-slowdown-budget 0.05   --specstream-coexec-guard-us 200"
```

Drafter：

```bash
export CAL_DRAFT_COMMON="$I2_DRAFT_COMMON   --specstream-smctrl-enabled   --specstream-smctrl-library '$SMCTRL_LIB'   --specstream-smctrl-mask-scope global"
```

q4/TPC4：

```bash
export TPC=4

export SPECSTREAM_TARGET_CMD="$CAL_TARGET_COMMON   --specstream-smctrl-calibration-tpcs $TPC   --specstream-smctrl-calibration-allow-overlap   --specstream-profile-path '$GATE_PROFILE'"

export SPECSTREAM_DRAFT_CMD="$CAL_DRAFT_COMMON   --specstream-smctrl-calibration-tpcs $TPC"
```

Target 启动日志必须出现：

```text
SpecStream draft-only true parallel: Target TPC mask is DISABLED;
Target keeps all visible TPCs while Drafter alone is TPC-limited
```

## 实验语义

建议正式保留三个消融：

```text
A. Naive co-run
   Target=[0,N), Draft=[0,N)

B. Draft-only throttling + true parallel（主方法）
   Target=[0,N), Draft=[0,k)

C. Complementary partition（消融）
   Target=[k,N), Draft=[0,k)
```

这样可以直接验证：相比严格互补分区，保留 Target 全部资源、只约束 Drafter
是否更适合 Draft–Verify 共执行。
