# SpecStream complementary TPC partition patch

This patch upgrades innovation point 2 from Draft-only throttling to true
complementary spatial partitioning during `SLACK_FILL`:

```text
Draft  : [0, k)
Target : [k, N)
```

After the asynchronous Target forward completes, Target is restored to
`[0,N)`.

It reuses the existing `TargetGrantRuntime` / `DraftGrantTable` protocol and
does not introduce a second grant state machine.

## Apply

From the SpecStream repository root:

```bash
python /path/to/apply_complementary_tpc_partition.py
python -m pip install -e ./python --no-deps

PYTHONPATH=python pytest -q \
  python/sglang/test/spectre_specstream/test_complementary_tpc_partition.py

PYTHONPATH=python pytest -q python/sglang/test/spectre_specstream
```

## Required flags

Target:

```bash
--specstream-smctrl-enabled \
--specstream-smctrl-mask-scope global \
--specstream-smctrl-complementary-partition
```

Drafter:

```bash
--specstream-smctrl-enabled \
--specstream-smctrl-mask-scope global
```

For fixed-TPC overlap calibration, both sides still receive the same
`--specstream-smctrl-calibration-tpcs k`; the Target additionally uses
`--specstream-smctrl-calibration-allow-overlap`.

For an A800 with 54 TPCs and k=4, an overlapping profile row should show:

```text
draft_tpc_low=0
draft_tpc_high=4
target_tpc_low=4
target_tpc_high=54
```

TPC partitioning does not isolate HBM bandwidth, L2, or memory controllers.
