#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import datetime
import py_compile
import shutil

REPO = Path.cwd()
BACKUP_ROOT = REPO / ".specstream_backups" / (
    "complementary_tpc_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
)

FILES = {
    "server_args": REPO / "python/sglang/srt/server_args.py",
    "config": REPO / "python/sglang/srt/speculative/spectre/specstream/config.py",
    "verifier": REPO / "python/sglang/srt/speculative/spectre/specstream/verifier.py",
    "worker": REPO / "python/sglang/srt/speculative/spectre/verifier/spectre_worker.py",
    "profiler": REPO / "python/sglang/srt/speculative/spectre/specstream/profiler.py",
    "readme": REPO / "csrc/specstream_smctrl/README.md",
}
NEW_MODULE = REPO / "python/sglang/srt/speculative/spectre/specstream/tpc_partition.py"
NEW_TEST = REPO / "python/sglang/test/spectre_specstream/test_complementary_tpc_partition.py"


def die(msg: str) -> None:
    raise SystemExit("ERROR: " + msg)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        die(f"{label}: expected exactly one anchor, found {count}")
    return text.replace(old, new, 1)


for name, path in FILES.items():
    if not path.exists():
        die(f"missing {name}: {path}")

staged = {name: path.read_text(encoding="utf-8") for name, path in FILES.items()}

# server_args.py
s = staged["server_args"]
s = replace_once(
    s,
    '''    specstream_smctrl_calibration_allow_overlap: bool = False
    specstream_tp_straggler_control: bool = False
''',
    '''    specstream_smctrl_calibration_allow_overlap: bool = False
    specstream_smctrl_complementary_partition: bool = False
    specstream_tp_straggler_control: bool = False
''',
    "server_args dataclass",
)
s = replace_once(
    s,
    '''        parser.add_argument(
            "--specstream-smctrl-calibration-allow-overlap",
            action="store_true",
            default=ServerArgs.specstream_smctrl_calibration_allow_overlap,
            help=(
                "Calibration only: issue fixed-TPC grants during Target forward "
                "to measure interference. Never use for the final online run."
            ),
        )
        parser.add_argument(
            "--specstream-tp-straggler-control",
''',
    '''        parser.add_argument(
            "--specstream-smctrl-calibration-allow-overlap",
            action="store_true",
            default=ServerArgs.specstream_smctrl_calibration_allow_overlap,
            help=(
                "Calibration only: issue fixed-TPC grants during Target forward "
                "to measure interference. Never use for the final online run."
            ),
        )
        parser.add_argument(
            "--specstream-smctrl-complementary-partition",
            action="store_true",
            default=ServerArgs.specstream_smctrl_complementary_partition,
            help=(
                "Use mutually exclusive TPC subsets during SLACK_FILL: Draft "
                "uses [0,k) and Target uses [k,N). Requires the validated "
                "process-global libsmctrl backend."
            ),
        )
        parser.add_argument(
            "--specstream-tp-straggler-control",
''',
    "server_args parser",
)
staged["server_args"] = s

# config.py
s = staged["config"]
s = replace_once(
    s,
    '''    smctrl_calibration_tpcs: int = 0
    smctrl_calibration_allow_overlap: bool = False
    tp_straggler_control: bool = False
''',
    '''    smctrl_calibration_tpcs: int = 0
    smctrl_calibration_allow_overlap: bool = False
    smctrl_complementary_partition: bool = False
    tp_straggler_control: bool = False
''',
    "config dataclass",
)
s = replace_once(
    s,
    '''        if self.smctrl_mask_scope not in {"stream", "global"}:
            raise ValueError("specstream_smctrl_mask_scope must be stream or global")
        if self.smctrl_calibration_allow_overlap and self.smctrl_calibration_tpcs < 1:
''',
    '''        if self.smctrl_mask_scope not in {"stream", "global"}:
            raise ValueError("specstream_smctrl_mask_scope must be stream or global")
        if self.smctrl_complementary_partition and not self.smctrl_enabled:
            raise ValueError(
                "complementary TPC partition requires --specstream-smctrl-enabled"
            )
        if (
            self.smctrl_complementary_partition
            and self.smctrl_mask_scope != "global"
        ):
            raise ValueError(
                "complementary TPC partition requires "
                "--specstream-smctrl-mask-scope global"
            )
        if self.smctrl_calibration_allow_overlap and self.smctrl_calibration_tpcs < 1:
''',
    "config validation",
)
s = replace_once(
    s,
    '''            smctrl_calibration_allow_overlap=bool(
                server_args.specstream_smctrl_calibration_allow_overlap
            ),
            tp_straggler_control=bool(server_args.specstream_tp_straggler_control),
''',
    '''            smctrl_calibration_allow_overlap=bool(
                server_args.specstream_smctrl_calibration_allow_overlap
            ),
            smctrl_complementary_partition=bool(
                server_args.specstream_smctrl_complementary_partition
            ),
            tp_straggler_control=bool(server_args.specstream_tp_straggler_control),
''',
    "config from_server_args",
)
staged["config"] = s

# verifier.py
s = staged["verifier"]
s = replace_once(
    s,
    '''from sglang.srt.speculative.spectre.specstream.gpu_grant_controller import (
    GpuGrantController,
)
''',
    '''from sglang.srt.speculative.spectre.specstream.gpu_grant_controller import (
    GpuGrantController,
    GrantState,
)
from sglang.srt.speculative.spectre.specstream.sm_controller import SMController
from sglang.srt.speculative.spectre.specstream.tpc_partition import (
    ComplementaryTPCPartition,
    build_complementary_tpc_partition,
)
''',
    "verifier imports",
)
s = replace_once(
    s,
    '''        self._round_id = 0
        self._tp_sync_counter = 0

        self.mps_environment = read_mps_environment()
''',
    '''        self._round_id = 0
        self._tp_sync_counter = 0
        self.target_smctrl = None
        self.target_total_tpcs = 0
        self._last_target_tpc_range: tuple[int, int] | None = None
        self._active_target_partition: ComplementaryTPCPartition | None = None

        if config.smctrl_enabled and config.smctrl_complementary_partition:
            self.target_smctrl = SMController(
                config.smctrl_library or None,
                device_index=(
                    int(model_runner.device.index)
                    if getattr(model_runner.device, "index", None) is not None
                    else None
                ),
                mask_scope="global",
            )
            self.target_total_tpcs = int(self.target_smctrl.total_tpcs)
            if self.target_total_tpcs > 64:
                raise RuntimeError(
                    "SpecStream complementary process-global TPC partition "
                    "currently supports at most 64 TPCs"
                )
            self._set_target_tpc_range(0, self.target_total_tpcs)
            logger.info(
                "SpecStream complementary Target TPC controller ready: "
                "full=[0,%d)",
                self.target_total_tpcs,
            )

        self.mps_environment = read_mps_environment()
''',
    "verifier target smctrl init",
)
marker = '''    def batch_requires_streaming(self, batch) -> bool:
'''
insert = '''    def _set_target_tpc_range(self, low: int, high: int) -> None:
        # Set the Target process-wide TPC mask and cache redundant switches.
        if self.target_smctrl is None:
            return
        requested = (int(low), int(high))
        if requested == self._last_target_tpc_range:
            return
        stream = torch.cuda.current_stream(self.model_runner.device)
        self.target_smctrl.set_stream_mask(stream, *requested)
        self._last_target_tpc_range = requested

    def _active_slack_fill_draft_ranges(self, batch) -> tuple[tuple[int, int], ...]:
        # Read the same outstanding SLACK_FILL grants that the Drafter obeys.
        if self.grant_runtime is None:
            return ()
        ranges = []
        for req in batch.reqs:
            if str(getattr(req, "rid", "")).startswith("HEALTH_CHECK"):
                continue
            state = self.grant_runtime.state_for(
                str(req.rid), int(getattr(req, "spec_cnt", 0) or 0)
            )
            if (
                state is None
                or state.outstanding_epoch is None
                or state.last_decision is None
                or state.last_decision.state is not GrantState.SLACK_FILL
            ):
                continue
            ranges.append(
                (
                    int(state.last_decision.tpc_low),
                    int(state.last_decision.tpc_high),
                )
            )
        return tuple(ranges)

    def begin_target_partition(self, batch, meta=None) -> bool:
        # During parallel SLACK_FILL: Draft=[0,k), Target=[k,N).
        if self.target_smctrl is None:
            return False
        if getattr(batch, "specstream_mode", "parallel") != "parallel":
            if meta is not None:
                self.profiler.record_target_partition(
                    meta.round_id, 0, self.target_total_tpcs
                )
            return False

        partition = build_complementary_tpc_partition(
            self.target_total_tpcs,
            self._active_slack_fill_draft_ranges(batch),
        )
        if partition is None:
            if meta is not None:
                self.profiler.record_target_partition(
                    meta.round_id, 0, self.target_total_tpcs
                )
            return False

        self._set_target_tpc_range(partition.target_low, partition.target_high)
        self._active_target_partition = partition
        if meta is not None:
            self.profiler.record_target_partition(
                meta.round_id, partition.target_low, partition.target_high
            )
        logger.debug(
            "[SpecStream][TPC] complementary overlap Draft=[%d,%d) "
            "Target=[%d,%d)",
            partition.draft_low,
            partition.draft_high,
            partition.target_low,
            partition.target_high,
        )
        return True

    def end_target_partition(self) -> None:
        # Restore Target=[0,N) only after the asynchronous Target forward ends.
        if self.target_smctrl is None or self._active_target_partition is None:
            return
        self._set_target_tpc_range(0, self.target_total_tpcs)
        self._active_target_partition = None

'''
if marker not in s:
    die("verifier method insertion anchor missing")
s = s.replace(marker, insert + marker, 1)
staged["verifier"] = s

# spectre_worker.py
s = staged["worker"]
old_extend = '''        if batch.forward_mode.is_extend() or batch.is_extend_in_batch:
            logits_output, next_token_ids, _ = self.forward_target_extend(batch)
            self._recv_drafts_after_extend(batch, next_token_ids)
            if self.specstream_runtime is not None:
                self.specstream_runtime.after_extend(batch)
            return GenerationBatchResult(
                logits_output=logits_output,
                next_token_ids=next_token_ids,
                num_accepted_tokens=0,
                can_run_cuda_graph=False,
            )
'''
new_extend = '''        if batch.forward_mode.is_extend() or batch.is_extend_in_batch:
            forward_done = self._target_forward_done_event
            current_stream = torch.cuda.current_stream()
            partition_active = False
            forward_recorded = False
            if self.specstream_runtime is not None:
                partition_active = self.specstream_runtime.begin_target_partition(
                    batch, None
                )
            try:
                logits_output, next_token_ids, _ = self.forward_target_extend(batch)
                forward_done.record(current_stream)
                forward_recorded = True
                batch.spectre_target_forward_done_event = forward_done
                self._recv_drafts_after_extend(batch, next_token_ids)
                forward_done.synchronize()
            finally:
                batch.spectre_target_forward_done_event = None
                if partition_active and self.specstream_runtime is not None:
                    if forward_recorded:
                        forward_done.synchronize()
                    self.specstream_runtime.end_target_partition()
            if self.specstream_runtime is not None:
                self.specstream_runtime.after_extend(batch)
            return GenerationBatchResult(
                logits_output=logits_output,
                next_token_ids=next_token_ids,
                num_accepted_tokens=0,
                can_run_cuda_graph=False,
            )
'''
s = replace_once(s, old_extend, new_extend, "worker extend forward")

old_verify = '''        forward_start = self._target_forward_start_event
        forward_done = self._target_forward_done_event
        current_stream = torch.cuda.current_stream()
        forward_start.record(current_stream)
        host_forward_started = time.perf_counter()
        batch_result = self.target_worker.forward_batch_generation(
            model_worker_batch, is_verify=True
        )
        host_forward_ms = (time.perf_counter() - host_forward_started) * 1000
        forward_done.record(current_stream)
        logits_output, can_run_cuda_graph = (
            batch_result.logits_output,
            batch_result.can_run_cuda_graph,
        )
        # The Target forward is asynchronous.  Receive the next-round remote
        # draft while its GPU work is executing, then wait only for this
        # forward's completion event before CPU/GPU result consumption.  A
        # device-wide synchronize here destroyed SPECTRE's Draft-Verify overlap
        # and also waited for unrelated D2H/H2D streams.
        new_drafts_per_req: dict = {}
        if recv_draft_fn is not None and not batch.forward_mode.is_idle():
            batch.spectre_target_forward_done_event = forward_done
            try:
                new_drafts_per_req = recv_draft_fn(batch)
            finally:
                batch.spectre_target_forward_done_event = None
            if getattr(batch, "spectre_draft_timeout", False):
                # The receive deadline already established Drafter overload.
                # A synchronous retry would add another half-timeout to the
                # same critical path; subsequent batches enter q=1 backoff
                # before the controller probes the Drafter again.
                retry_fn = None
        forward_done.synchronize()
        gpu_forward_ms = forward_start.elapsed_time(forward_done)
        if self.specstream_runtime is not None:
            self.specstream_runtime.record_target_forward(
                specstream_meta, gpu_forward_ms, enqueue_ms=host_forward_ms
            )
'''
new_verify = '''        forward_start = self._target_forward_start_event
        forward_done = self._target_forward_done_event
        current_stream = torch.cuda.current_stream()

        partition_active = False
        forward_recorded = False
        forward_completed = False
        if self.specstream_runtime is not None:
            partition_active = self.specstream_runtime.begin_target_partition(
                batch, specstream_meta
            )

        try:
            forward_start.record(current_stream)
            host_forward_started = time.perf_counter()
            batch_result = self.target_worker.forward_batch_generation(
                model_worker_batch, is_verify=True
            )
            host_forward_ms = (time.perf_counter() - host_forward_started) * 1000
            forward_done.record(current_stream)
            forward_recorded = True
            logits_output, can_run_cuda_graph = (
                batch_result.logits_output,
                batch_result.can_run_cuda_graph,
            )
            new_drafts_per_req: dict = {}
            if recv_draft_fn is not None and not batch.forward_mode.is_idle():
                batch.spectre_target_forward_done_event = forward_done
                try:
                    new_drafts_per_req = recv_draft_fn(batch)
                finally:
                    batch.spectre_target_forward_done_event = None
                if getattr(batch, "spectre_draft_timeout", False):
                    retry_fn = None
            forward_done.synchronize()
            forward_completed = True
            gpu_forward_ms = forward_start.elapsed_time(forward_done)
        finally:
            batch.spectre_target_forward_done_event = None
            if partition_active and self.specstream_runtime is not None:
                if forward_recorded and not forward_completed:
                    forward_done.synchronize()
                self.specstream_runtime.end_target_partition()

        if self.specstream_runtime is not None:
            self.specstream_runtime.record_target_forward(
                specstream_meta, gpu_forward_ms, enqueue_ms=host_forward_ms
            )
'''
s = replace_once(s, old_verify, new_verify, "worker verify forward")
staged["worker"] = s

# profiler.py
s = staged["profiler"]
s = replace_once(
    s,
    '''    draft_tpc_low: int = -1
    draft_tpc_high: int = -1
    mps_active_thread_percentage: int = 0
''',
    '''    draft_tpc_low: int = -1
    draft_tpc_high: int = -1
    target_tpc_low: int = -1
    target_tpc_high: int = -1
    mps_active_thread_percentage: int = 0
''',
    "profiler row fields",
)
anchor = '''    def record_h2d(
'''
method = '''    def record_target_partition(
        self, round_id: int, tpc_low: int, tpc_high: int
    ) -> None:
        row = self._active.get(int(round_id))
        if row is None:
            return
        row.target_tpc_low = int(tpc_low)
        row.target_tpc_high = int(tpc_high)

'''
if anchor not in s:
    die("profiler record_target_partition anchor missing")
s = s.replace(anchor, method + anchor, 1)
staged["profiler"] = s

# README
s = staged["readme"]
s = replace_once(
    s,
    '''Only after this target passes on the exact GPU/driver combination may the
Drafter be launched with `--specstream-smctrl-mask-scope global`.  This scope
is process-wide: it is correct for SpecStream's dedicated Drafter process, but
must not be enabled in a process that also runs unmasked Target kernels.
''',
    '''Only after this target passes on the exact GPU/driver combination may a
dedicated SpecStream process use `--specstream-smctrl-mask-scope global`.
This scope is process-wide. The remote Drafter may use Draft=[0,k); when
`--specstream-smctrl-complementary-partition` is enabled, the separate Target
process temporarily uses the complementary Target=[k,N) mask for the
overlapping Target forward and restores [0,N) after its completion. Do not
enable the global backend inside a process that mixes kernels which are meant
to be masked with kernels which must remain independently unmasked.
''',
    "README global-mask semantics",
)
staged["readme"] = s

for key in ("server_args", "config", "verifier", "worker", "profiler"):
    compile(staged[key], str(FILES[key]), "exec")

bundle_dir = Path(__file__).resolve().parent
new_module_src = (bundle_dir / "tpc_partition.py").read_text(encoding="utf-8")
new_test_src = (bundle_dir / "test_complementary_tpc_partition.py").read_text(encoding="utf-8")
compile(new_module_src, str(NEW_MODULE), "exec")
compile(new_test_src, str(NEW_TEST), "exec")

BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
for path in list(FILES.values()) + [NEW_MODULE, NEW_TEST]:
    if path.exists():
        rel = path.relative_to(REPO)
        dst = BACKUP_ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dst)

for key, path in FILES.items():
    path.write_text(staged[key], encoding="utf-8")
NEW_MODULE.parent.mkdir(parents=True, exist_ok=True)
NEW_MODULE.write_text(new_module_src, encoding="utf-8")
NEW_TEST.parent.mkdir(parents=True, exist_ok=True)
NEW_TEST.write_text(new_test_src, encoding="utf-8")

for path in (
    FILES["server_args"],
    FILES["config"],
    FILES["verifier"],
    FILES["worker"],
    FILES["profiler"],
    NEW_MODULE,
    NEW_TEST,
):
    py_compile.compile(str(path), doraise=True)

print("=" * 72)
print("SpecStream complementary TPC partition patch applied")
print("=" * 72)
print("Backup:", BACKUP_ROOT)
print("SLACK_FILL: Draft=[0,k), Target=[k,N)")
print("After Target forward: Target=[0,N)")
print("New CLI: --specstream-smctrl-complementary-partition")
print("Profile columns: target_tpc_low, target_tpc_high")
