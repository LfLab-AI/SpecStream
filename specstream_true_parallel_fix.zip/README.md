# SpecStream true Draft–Verify parallel execution patch

This patch fixes the remaining **temporal serialization** after the complementary-TPC patch.

Before, only the first Draft token could overlap the Target forward:

```text
Target : |================ VERIFY ================|
Draft  : |D1|                                     |D2|D3|D4|
```

After this patch, each one-token ACK immediately refills another `SLACK_FILL` grant while the Target CUDA completion event is still incomplete:

```text
Target : |================ VERIFY ================|
Draft  :   |D1| |D2| |D3| |D4|
```

If Target finishes first, remaining Draft work switches to `DRAFT_CATCHUP`.

Safety properties kept:

- one outstanding grant per request;
- one grant = one Draft token;
- ACK required before next token;
- repeated overlap grants reuse the initial Draft TPC range;
- online overlap uses one absolute deadline and never extends it;
- `PREFILL_DEFERRED` blocks repeated overlap grants;
- Target complementary mask is installed before the first Draft grant is visible.

Apply from `~/lifei/SpecStream` **after** the complementary-TPC patch:

```bash
python /path/to/apply_true_parallel_fix.py
python -m pip install -e ./python --no-deps

PYTHONPATH=python pytest -q \
  python/sglang/test/spectre_specstream/test_coexec_runtime.py

PYTHONPATH=python pytest -q \
  python/sglang/test/spectre_specstream
```

Then rerun the small `q=4 / TPC=4 / C1 / 4-request` complementary gate before any 200-request calibration.

For paper-grade proof that GPU kernels really overlap, capture an Nsight Systems timeline after the gate. The scheduler patch creates true continuous-overlap opportunities; the timeline is the definitive hardware-level validation.
