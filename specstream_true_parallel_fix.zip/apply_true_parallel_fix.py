#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import datetime
import py_compile
import shutil

REPO = Path.cwd()
FILES = {
    "coexec": REPO / "python/sglang/srt/speculative/spectre/specstream/coexec_runtime.py",
    "verifier": REPO / "python/sglang/srt/speculative/spectre/specstream/verifier.py",
    "target_sched": REPO / "python/sglang/srt/speculative/spectre/verifier/spectre_target_scheduler_mixin.py",
    "tests": REPO / "python/sglang/test/spectre_specstream/test_coexec_runtime.py",
}
stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
BACKUP = REPO / ".specstream_backups" / f"true_parallel_{stamp}"

def die(msg: str):
    raise SystemExit("ERROR: " + msg)

def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        die(f"{label}: expected exactly one anchor, found {count}")
    return text.replace(old, new, 1)

for name, path in FILES.items():
    if not path.exists():
        die(f"missing {name}: {path}")

src = {k: p.read_text(encoding="utf-8") for k, p in FILES.items()}

if "smctrl_complementary_partition" not in src["verifier"]:
    die("complementary TPC patch is not present in verifier.py")
if "begin_target_partition" not in src["verifier"]:
    die("verifier.py has no begin_target_partition(); complementary patch incomplete")

# ---------------------------------------------------------------------------
# 1) coexec_runtime.py: repeated one-token SLACK_FILL while Target is running.
# ---------------------------------------------------------------------------
s = src["coexec"]
s = replace_once(
    s,
    '''    last_grant_wait_ms: float = 0.0\n    last_decision: GrantDecision | None = None\n''',
    '''    last_grant_wait_ms: float = 0.0\n    last_decision: GrantDecision | None = None\n    # The first SLACK_FILL grant opens one overlap window for this round.\n    # Continuations must reuse the exact same Draft TPC range so they stay\n    # disjoint from Target's already-installed complementary [k,N) mask.\n    overlap_open: bool = False\n    overlap_blocked: bool = False\n    overlap_tpc_low: int = 0\n    overlap_tpc_high: int = 0\n    # Absolute CLOCK_MONOTONIC deadline for the entire Target overlap window.\n    # ACK/regrant cycles must never extend this deadline.\n    overlap_deadline_us: int | None = None\n    overlap_grants_issued: int = 0\n    catchup_grants_issued: int = 0\n''',
    "round-state fields",
)

s = replace_once(
    s,
    '''    def _issue(\n        self,\n        state: _RoundGrantState,\n        *,\n        target_waiting: bool,\n        deadline_us: int | None,\n    ) -> SpectreRequest | None:\n        if state.outstanding_epoch is not None or state.issued >= state.desired_q:\n            return None\n        decision = self.controller.decide(\n            target_shape=state.target_shape,\n            draft_bs=state.draft_bs,\n            draft_ctx_bucket=state.draft_ctx_bucket,\n            predicted_slack_us=state.predicted_slack_us,\n            target_waiting=target_waiting,\n            deadline_us=deadline_us,\n        )\n''',
    '''    def _issue(\n        self,\n        state: _RoundGrantState,\n        *,\n        target_waiting: bool,\n        deadline_us: int | None,\n        decision_override: GrantDecision | None = None,\n    ) -> SpectreRequest | None:\n        if state.outstanding_epoch is not None or state.issued >= state.desired_q:\n            return None\n        decision = decision_override or self.controller.decide(\n            target_shape=state.target_shape,\n            draft_bs=state.draft_bs,\n            draft_ctx_bucket=state.draft_ctx_bucket,\n            predicted_slack_us=state.predicted_slack_us,\n            target_waiting=target_waiting,\n            deadline_us=deadline_us,\n        )\n''',
    "_issue signature",
)

s = replace_once(
    s,
    '''        state.issued += 1\n        state.outstanding_epoch = epoch\n        state.outstanding_since = time.perf_counter()\n''',
    '''        if decision.state is GrantState.SLACK_FILL:\n            if not state.overlap_open:\n                state.overlap_open = True\n                state.overlap_tpc_low = int(decision.tpc_low)\n                state.overlap_tpc_high = int(decision.tpc_high)\n                state.overlap_deadline_us = effective_deadline_us\n            state.overlap_grants_issued += 1\n        elif decision.state is GrantState.DRAFT_CATCHUP:\n            state.catchup_grants_issued += 1\n\n        state.issued += 1\n        state.outstanding_epoch = epoch\n        state.outstanding_since = time.perf_counter()\n''',
    "grant accounting",
)

anchor = '''    def waiting_grants(\n        self,\n        keys: list[tuple[str, int]],\n        *,\n        deadline_us: int,\n    ) -> list[SpectreRequest]:\n'''
if anchor not in s:
    die("coexec waiting_grants anchor missing")

overlap_method = '''    def overlap_grants(\n        self,\n        keys: list[tuple[str, int]],\n        *,\n        now_us: int | None = None,\n    ) -> list[SpectreRequest]:\n        \"\"\"Continue one-token SLACK_FILL while Target CUDA is still running.\n\n        One request still has at most one outstanding grant.  Continuation is\n        legal only if an initial SLACK_FILL grant opened the round before\n        Target launch.  The Draft TPC range and absolute deadline are frozen\n        for the whole overlap window.\n        \"\"\"\n        now = time.monotonic_ns() // 1000 if now_us is None else int(now_us)\n        messages: list[SpectreRequest] = []\n        for key in keys:\n            state = self._rounds.get(key)\n            if state is None:\n                continue\n            if not state.overlap_open or state.overlap_blocked:\n                continue\n            if state.outstanding_epoch is not None or state.issued >= state.desired_q:\n                continue\n            if (\n                state.overlap_deadline_us is not None\n                and now >= int(state.overlap_deadline_us)\n            ):\n                continue\n\n            frozen = GrantDecision(\n                GrantState.SLACK_FILL,\n                \"continuous_slack_fill\",\n                int(state.overlap_tpc_low),\n                int(state.overlap_tpc_high),\n                state.overlap_deadline_us,\n                (\n                    state.last_decision.profile_entry\n                    if state.last_decision is not None\n                    else None\n                ),\n            )\n            message = self._issue(\n                state,\n                target_waiting=False,\n                deadline_us=state.overlap_deadline_us,\n                decision_override=frozen,\n            )\n            if message is not None:\n                messages.append(message)\n        return messages\n\n'''
s = s.replace(anchor, overlap_method + anchor, 1)

s = replace_once(
    s,
    '''        if ack_tokens == 0:\n            # A Drafter can explicitly defer a re-prefill grant that was\n            # calibrated only for decode.  It consumed no token budget, so the\n            # next DRAFT_CATCHUP quantum must still be issuable.\n            state.issued = max(state.issued - 1, state.acked)\n            return True\n''',
    '''        if ack_tokens == 0:\n            # Re-prefill is not calibrated for SLACK_FILL.  Do not create a\n            # zero-token ACK -> overlap-grant loop; wait for DRAFT_CATCHUP.\n            state.issued = max(state.issued - 1, state.acked)\n            state.overlap_blocked = True\n            return True\n''',
    "zero-token overlap blocking",
)
src["coexec"] = s

# ---------------------------------------------------------------------------
# 2) verifier.py: expose overlap_grants to Target scheduler.
# ---------------------------------------------------------------------------
s = src["verifier"]
anchor = '''    def waiting_grants(self, keys, *, deadline_us: int):\n'''
if anchor not in s:
    die("verifier waiting_grants wrapper anchor missing")
wrapper = '''    def overlap_grants(self, keys, *, now_us: int | None = None):\n        if self.grant_runtime is None:\n            return []\n        messages = self.grant_runtime.overlap_grants(\n            list(keys), now_us=now_us\n        )\n        for message in messages:\n            self.profiler.record_grant(message, target_phase=\"target_forward\")\n        return messages\n\n'''
s = s.replace(anchor, wrapper + anchor, 1)
src["verifier"] = s

# ---------------------------------------------------------------------------
# 3) Target scheduler: continuous SLACK_FILL + pre-arm complement before send.
# ---------------------------------------------------------------------------
s = src["target_sched"]
old_pump = '''        def pump_waiting_grants() -> None:\n            if runtime is None or not pending_rids or not target_forward_complete():\n                return\n            keys = [key for key in grant_keys if key[0] in pending_rids]\n            grant_messages = runtime.waiting_grants(keys, deadline_us=grant_deadline_us)\n            if grant_messages:\n                self._zmq_send(grant_messages)\n\n        # DRAFT_CATCHUP is issued only after the asynchronous Target CUDA\n        # forward has completed.  Before that point, only an offline-approved\n        # SLACK_FILL grant sent at round start may execute.\n        pump_waiting_grants()\n\n        while pending_rids:\n            pump_waiting_grants()\n'''
new_pump = '''        def pump_grants() -> None:\n            if runtime is None or not pending_rids:\n                return\n            keys = [key for key in grant_keys if key[0] in pending_rids]\n            if not keys:\n                return\n\n            if target_forward_complete():\n                # Target critical CUDA forward has completed: remaining Draft\n                # work is catchup and may consume the calibrated catchup quota.\n                grant_messages = runtime.waiting_grants(\n                    keys, deadline_us=grant_deadline_us\n                )\n            else:\n                # True Draft-Verify co-execution.  An ACK clears the previous\n                # one-token epoch; refill another SLACK_FILL quantum while the\n                # Target completion event is still incomplete.\n                grant_messages = runtime.overlap_grants(\n                    keys, now_us=time.monotonic_ns() // 1000\n                )\n\n            if grant_messages:\n                self._zmq_send(grant_messages)\n\n        # Initial SLACK_FILL was sent with the Draft request.  From now on,\n        # ACKs can continuously refill the Target-forward overlap window.\n        pump_grants()\n\n        while pending_rids:\n            pump_grants()\n'''
s = replace_once(s, old_pump, new_pump, "continuous grant pump")

s = replace_once(
    s,
    '''                if not pending_rids:\n                    break\n                pump_waiting_grants()\n''',
    '''                if not pending_rids:\n                    break\n                # ACK may have just cleared the outstanding epoch.\n                pump_grants()\n''',
    "post-ACK grant refill",
)

old_send = '''                if draft_reqs:\n                    runtime = self._get_specstream_runtime()\n                    grant_reqs = (\n                        runtime.prepare_initial_grants(\n                            batch, speculative_num_draft_tokens\n                        )\n                        if runtime is not None\n                        else []\n                    )\n                    batch.spectre_draft_request_sent = self._zmq_send(\n                        draft_reqs + grant_reqs,\n                        wait_for_identity_s=(\n                            self._initial_recv_timeout_s\n                            if any(req.spec_cnt <= 0 for req in reqs_to_send)\n                            else 0.0\n                        ),\n                    )\n'''
new_send = '''                if draft_reqs:\n                    runtime = self._get_specstream_runtime()\n                    grant_reqs = (\n                        runtime.prepare_initial_grants(\n                            batch, speculative_num_draft_tokens\n                        )\n                        if runtime is not None\n                        else []\n                    )\n\n                    # Install Target=[k,N) before the first SLACK_FILL grant is\n                    # visible to Drafter.  This closes the old launch-order race\n                    # where Draft could observe [0,k) before Target had applied\n                    # its complementary process-global mask.\n                    partition_prearmed = False\n                    if grant_reqs and runtime is not None:\n                        begin_partition = getattr(\n                            runtime, \"begin_target_partition\", None\n                        )\n                        if begin_partition is not None:\n                            partition_prearmed = bool(\n                                begin_partition(batch, None)\n                            )\n\n                    batch.spectre_target_partition_prearmed = partition_prearmed\n                    batch.spectre_draft_request_sent = self._zmq_send(\n                        draft_reqs + grant_reqs,\n                        wait_for_identity_s=(\n                            self._initial_recv_timeout_s\n                            if any(req.spec_cnt <= 0 for req in reqs_to_send)\n                            else 0.0\n                        ),\n                    )\n                    if not batch.spectre_draft_request_sent and partition_prearmed:\n                        end_partition = getattr(\n                            runtime, \"end_target_partition\", None\n                        )\n                        if end_partition is not None:\n                            end_partition()\n                        batch.spectre_target_partition_prearmed = False\n'''
s = replace_once(s, old_send, new_send, "pre-arm Target complement")
src["target_sched"] = s

# ---------------------------------------------------------------------------
# 4) Unit tests.
# ---------------------------------------------------------------------------
s = src["tests"]
if "test_continuous_overlap_reissues_before_target_completion" in s:
    die("true-parallel tests already present; refusing duplicate apply")

tests_append = r'''


def _ack(grant, *, tokens=1, state=None):
    return SpectreRequest(
        request_id=grant.request_id,
        spec_cnt=grant.spec_cnt,
        action=SpectreAction.GRANT_ACK,
        grant_epoch=grant.grant_epoch,
        grant_tokens=tokens,
        grant_state=state or grant.grant_state,
    )


def test_continuous_overlap_reissues_before_target_completion():
    runtime = _runtime()
    runtime.register_round(
        request_id="r",
        spec_cnt=1,
        desired_q=4,
        target_shape="shape",
        draft_bs=1,
        draft_ctx_bucket="2k",
        predicted_slack_us=100000,
    )
    first = runtime.initial_grants([("r", 1)])[0]
    assert first.grant_state == "SLACK_FILL"
    deadline = int(first.deadline_us)
    grants = [first]

    for _ in range(3):
        assert runtime.overlap_grants([("r", 1)], now_us=deadline - 1) == []
        assert runtime.acknowledge(_ack(grants[-1]))
        nxt = runtime.overlap_grants([("r", 1)], now_us=deadline - 1)
        assert len(nxt) == 1
        assert nxt[0].grant_state == "SLACK_FILL"
        assert int(nxt[0].deadline_us) == deadline
        assert (nxt[0].tpc_low, nxt[0].tpc_high) == (
            first.tpc_low,
            first.tpc_high,
        )
        grants.append(nxt[0])

    assert len(grants) == 4
    assert runtime.acknowledge(_ack(grants[-1]))
    assert runtime.overlap_grants([("r", 1)], now_us=deadline - 1) == []


def test_overlap_deadline_is_absolute_and_never_extended():
    runtime = _runtime()
    runtime.register_round(
        request_id="r",
        spec_cnt=1,
        desired_q=3,
        target_shape="shape",
        draft_bs=1,
        draft_ctx_bucket="2k",
        predicted_slack_us=100000,
    )
    first = runtime.initial_grants([("r", 1)])[0]
    deadline = int(first.deadline_us)
    assert runtime.acknowledge(_ack(first))
    second = runtime.overlap_grants([("r", 1)], now_us=deadline - 1)
    assert len(second) == 1
    assert int(second[0].deadline_us) == deadline
    assert runtime.acknowledge(_ack(second[0]))
    assert runtime.overlap_grants([("r", 1)], now_us=deadline) == []


def test_prefill_deferred_blocks_continuous_overlap_but_allows_catchup():
    runtime = _runtime()
    runtime.register_round(
        request_id="r",
        spec_cnt=1,
        desired_q=2,
        target_shape="shape",
        draft_bs=1,
        draft_ctx_bucket="2k",
        predicted_slack_us=100000,
    )
    first = runtime.initial_grants([("r", 1)])[0]
    assert runtime.acknowledge(
        _ack(first, tokens=0, state="PREFILL_DEFERRED")
    )
    assert runtime.overlap_grants([("r", 1)]) == []
    catchup = runtime.waiting_grants([("r", 1)], deadline_us=10**18)
    assert len(catchup) == 1
    assert catchup[0].grant_state == "DRAFT_CATCHUP"


def test_calibration_can_fill_multiple_overlap_quanta():
    runtime = TargetGrantRuntime(
        GpuGrantController(
            None,
            calibration_tpcs=4,
            calibration_allow_overlap=True,
        )
    )
    runtime.register_round(
        request_id="r",
        spec_cnt=1,
        desired_q=4,
        target_shape="shape",
        draft_bs=1,
        draft_ctx_bucket="2k",
        predicted_slack_us=0,
    )
    grant = runtime.initial_grants([("r", 1)])[0]
    assert grant.deadline_us is None
    total = 1
    while total < 4:
        assert runtime.acknowledge(_ack(grant))
        nxt = runtime.overlap_grants([("r", 1)])
        assert len(nxt) == 1
        grant = nxt[0]
        assert grant.grant_state == "SLACK_FILL"
        assert grant.deadline_us is None
        assert (grant.tpc_low, grant.tpc_high) == (0, 4)
        total += 1
'''
s = s.rstrip() + tests_append + "\n"
src["tests"] = s

# Validate all staged Python before modifying repo.
for key in ("coexec", "verifier", "target_sched", "tests"):
    compile(src[key], str(FILES[key]), "exec")

BACKUP.mkdir(parents=True, exist_ok=True)
for path in FILES.values():
    dst = BACKUP / path.relative_to(REPO)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dst)

for key, path in FILES.items():
    path.write_text(src[key], encoding="utf-8")
    py_compile.compile(str(path), doraise=True)

print("=" * 78)
print("SpecStream true Draft-Verify continuous-overlap patch applied")
print("=" * 78)
print("backup:", BACKUP)
print("Target running: ACK -> next one-token SLACK_FILL immediately")
print("Target done   : remaining tokens -> DRAFT_CATCHUP")
print("one outstanding grant/request is preserved")
print("online overlap uses one absolute deadline")
print("Target complement is pre-armed before first Draft grant")
